/*:
@target MZ

@plugindesc
全ての行動で、クリティカルヒットが
出るようになるテスト用のプラグインです。

@author
シトラス

@help
このプラグインはWTFPLライセンスで公開します。
ですができれば、ゲーム内などに名前を表示してくれるとありがたいです。

@url
https://github.com/citrusXojsduedchuio/tkoolplugins
*/
(() => {
	'use strict'
	Game_Action.prototype.itemCri = function(target) {
		return 1;
	};
})();