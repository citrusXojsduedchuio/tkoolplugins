/*:
@target MZ

@plugindesc
運の値により、クリティカル率が上昇します。

@author
シトラス
@help
このプラグインはWTFPLライセンスで公開します。
ですができれば、ゲーム内などに名前を表示してくれるとありがたいです。

@url
https://github.com/citrusXojsduedchuio/tkoolplugins
*/
(() => {
	'use strict'
	Game_Action.prototype.itemCri = function(target) {
		const a = this.subjuct();
		if(this.item().damage.critical){
			return 0;
		}
		if(a.cri <= 0){
			return 0;
		}
		return (a.cri + a.luk/1000)*(1 - target.cev);
	};
})();